package com.example.lr5

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.fragment.app.Fragment

class ProductCategoriesFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.product_categories_fragment, container, false)

        // Заповнення списку категорій
        val categoriesListView = view.findViewById<ListView>(R.id.productCategories)
        val categoriesArray = resources.getStringArray(R.array.product_categories)
        val adapter = ArrayAdapter(requireContext(),
            android.R.layout.simple_list_item_1, categoriesArray)
        categoriesListView.adapter = adapter

        // Відправка повідомлення про назву фрагменту
        val result = Bundle().apply { putString("fragment_name", "ProductCategoriesFragment") }
        parentFragmentManager.setFragmentResult("requestKey", result)

        return view
    }

    companion object {
        @JvmStatic
        fun newInstance() = ProductCategoriesFragment()
    }
}
