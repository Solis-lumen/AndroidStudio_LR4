/*
package com.example.lr5

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import androidx.fragment.app.Fragment

class ProductImagesFragment : Fragment() {
    var counter = 0
    val imagesCount = 3
    lateinit var imageView : ImageView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.product_images_fragment, container, false)
        // Обробка подій перемикання зображень
        imageView = view.findViewById<ImageView>(R.id.productImageView)
        view.findViewById<Button>(R.id.buttonLeft).setOnClickListener {
            onClickLeft()
        }
        view.findViewById<Button>(R.id.buttonRight).setOnClickListener {
            onClickRight()
        }
        //Відправка повідомлення про назву фрагменту
        val result = Bundle().apply { putString("fragment_name", "ProductImagesFragment") }
        parentFragmentManager.setFragmentResult("requestKey", result)
        return view
    }

    companion object {
        @JvmStatic
        fun newInstance() = ProductImagesFragment()
    }

    fun onClickRight() {
        counter += 1
        if (counter > imagesCount)
            counter = 0
        updateImage()
    }

    fun onClickLeft() {
        counter -= 1
        if (counter < 0)
            counter = imagesCount - 1
        updateImage()
    }

    fun updateImage() {
        // Масив зображень з папки drawable
        val images = arrayOf(
            R.drawable.silver_super_car,
            R.drawable.green_bike,
        )

        // Оновлення зображення в ImageView
        imageView.setImageResource(images[counter])
    }
}
*/





package com.example.lr5

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import androidx.fragment.app.Fragment

class ProductImagesFragment : Fragment() {
    var counter = 0
    lateinit var imageView: ImageView
    val imagesArray = intArrayOf(
        R.drawable.silver_super_car,
        R.drawable.green_bike,
        R.drawable.bicycle,
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.product_images_fragment, container, false)

        imageView = view.findViewById(R.id.productImageView)

        // Обробка подій для кнопок
        view.findViewById<Button>(R.id.buttonLeft).setOnClickListener {
            onClickLeft()
        }
        view.findViewById<Button>(R.id.buttonRight).setOnClickListener {
            onClickRight()
        }

        // Відображення початкового зображення
        updateImage()

        // Відправка повідомлення про назву фрагменту
        val result = Bundle().apply { putString("fragment_name", "ProductImagesFragment") }
        parentFragmentManager.setFragmentResult("requestKey", result)
        return view
    }

    companion object {
        @JvmStatic
        fun newInstance() = ProductImagesFragment()
    }

    fun onClickRight() {
        counter = (counter + 1) % imagesArray.size
        updateImage()
    }

    fun onClickLeft() {
        counter = if (counter - 1 < 0) imagesArray.size - 1 else counter - 1
        updateImage()
    }

    // Метод для оновлення зображення
    fun updateImage() {
        imageView.setImageResource(imagesArray[counter])
    }
}
