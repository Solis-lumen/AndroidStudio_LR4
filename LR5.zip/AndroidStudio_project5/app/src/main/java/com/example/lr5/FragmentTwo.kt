/*
package com.example.lr5

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import kotlin.random.Random

class FragmentTwo : Fragment() {
    private lateinit var textView: TextView
    private lateinit var layout: LinearLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_two, container, false)
        textView = view.findViewById(R.id.textFragmentTwo) // Посилання на TextView
        textView.text = "Text for Fragment 2"
        layout = view.findViewById(R.id.mainLayoutTwo)
        return view
    }

    // Метод для оновлення тексту
    fun updateColor() {
        layout.setBackgroundColor(getRandomColor())
    }

    private fun getRandomColor(): Int {
        val rnd = Random
        return Color.rgb(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
    }
}
*/




package com.example.lr5

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import kotlin.random.Random

class FragmentTwo : Fragment() {
    private lateinit var textView: TextView
    private lateinit var layout: LinearLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_two, container, false)
        textView = view.findViewById(R.id.textFragmentTwo)
        layout = view.findViewById(R.id.mainLayoutTwo) // Посилання на контейнер
        return view
    }

    fun updateTextBG(newText: String) {
        if (::textView.isInitialized) { // Перевірка на ініціалізацію textView
            textView.text = newText
            layout.setBackgroundColor(getRandomColor())
        }
    }

    private fun getRandomColor(): Int {
        val rnd = Random
        return Color.rgb(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
    }
}