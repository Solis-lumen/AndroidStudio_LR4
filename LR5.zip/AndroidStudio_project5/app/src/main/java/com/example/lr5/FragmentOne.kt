/*
package com.example.lr5

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import kotlin.random.Random

class FragmentOne : Fragment() {
    private lateinit var textView: TextView
    private lateinit var layout: LinearLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_one, container, false)
        textView = view.findViewById(R.id.textFragmentOne) // Посилання на TextView
        textView.text = "Text for Fragment 1"
        layout = view.findViewById(R.id.mainLayoutOne)
        return view
    }

    // Метод для оновлення тексту
    fun updateColor() {
        layout.setBackgroundColor(getRandomColor())
    }

    private fun getRandomColor(): Int {
        val rnd = Random
        return Color.rgb(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
    }
}
*/




package com.example.lr5

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import kotlin.random.Random

class FragmentOne : Fragment() {
    private lateinit var textView: TextView
    private lateinit var layout: LinearLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_one, container, false)
        textView = view.findViewById(R.id.textFragmentOne)
        layout = view.findViewById(R.id.mainLayoutOne)
        return view
    }

    fun updateTextBG(newText: String) {
        if (::textView.isInitialized) {
            textView.text = newText
            layout.setBackgroundColor(getRandomColor())
        }
    }

    private fun getRandomColor(): Int {
        val rnd = Random
        return Color.rgb(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
    }
}