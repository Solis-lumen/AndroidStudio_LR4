// показ із подвійним натисканням кнопок
/*
package com.example.lr5

import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager

class MainActivity : AppCompatActivity() {
    private lateinit var fragmentOne: FragmentOne
    private lateinit var fragmentTwo: FragmentTwo

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        fragmentOne = FragmentOne()
        fragmentTwo = FragmentTwo()

        // Завантажуємо перший фрагмент за замовчуванням
        loadFragment(fragmentOne)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun loadFragment(fragment: Fragment) {
        val fragmentManager: FragmentManager = supportFragmentManager
        val transaction = fragmentManager.beginTransaction()

        // Додаємо фрагмент, якщо він ще не додано
        if (fragmentManager.findFragmentById(R.id.fragmentContainer) == null) {
            transaction.add(R.id.fragmentContainer, fragment)
        } else {
            // Заміна фрагмента у контейнері
            transaction.replace(R.id.fragmentContainer, fragment)
        }
        transaction.commit()
    }

    fun button1Click(view: View) {
        loadFragment(fragmentOne) // Завантажуємо перший фрагмент
        fragmentOne.updateText("Hello from Fragment One!") // Оновлюємо текст у фрагменті
    }

    fun button2Click(view: View) {
        loadFragment(fragmentTwo) // Завантажуємо другий фрагмент
        fragmentTwo.updateText("Hello from Fragment Two!") // Оновлюємо текст у фрагменті
    }
}
 */


package com.example.lr5

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager

class MainActivity : AppCompatActivity() {
    private lateinit var fragmentOne: FragmentOne
    private lateinit var fragmentTwo: FragmentTwo
    private lateinit var fragmentCategories: ProductCategoriesFragment
    private lateinit var fragmentBoughtProducts: BoughtProductsFragment
    private lateinit var fragmentProductImages: ProductImagesFragment
    private var currentFragmentIndex = 2 // Лічильник для відслідковування поточного фрагменту
    private lateinit var fragmentList: List<Fragment> // Список фрагментів

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i("MainActivityEvent", "onCreate")
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        fragmentOne = FragmentOne()
        fragmentTwo = FragmentTwo()
        fragmentProductImages = ProductImagesFragment()
        fragmentCategories = ProductCategoriesFragment()
        fragmentBoughtProducts = BoughtProductsFragment()

        // Ініціалізуємо список фрагментів
        fragmentList = listOf(fragmentCategories, fragmentBoughtProducts, fragmentProductImages)

        // Завантаження фрагментів
        loadFragments()

        // Заповнення frameLayout3 початковим фрагментом
        showOtherFragment(fragmentList[currentFragmentIndex], R.id.frameLayout3)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Отримання повідомлення від фрагменту про його назву
        val fragmentNameTextView = findViewById<TextView>(R.id.textView3)
        supportFragmentManager.setFragmentResultListener("requestKey", this) { requestKey, bundle ->
            if (requestKey == "requestKey") {
                val fragmentName = bundle.getString("fragment_name")
                fragmentNameTextView.text = fragmentName // Оновлення TextView
            }
        }

        supportFragmentManager.beginTransaction().replace(R.id.frameLayoutSwitchActivity, SwitchActivityFragment.newInstance()).commit()
    }

    private fun loadFragments() {
        val fragmentManager: FragmentManager = supportFragmentManager
        val transaction = fragmentManager.beginTransaction()
        transaction.add(R.id.fragmentContainer, fragmentOne)
        transaction.add(R.id.fragmentContainer, fragmentTwo)
        transaction.hide(fragmentTwo)
        transaction.commit()
    }

    private fun showFragment(fragment: Fragment) {
        val fragmentManager: FragmentManager = supportFragmentManager
        val transaction = fragmentManager.beginTransaction()
        transaction.setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right)
        //transaction.hide(fragmentOne)
        transaction.hide(fragmentTwo)
        transaction.show(fragment)
        //transaction.replace(R.id.frameLayout3, fragment)
        transaction.commit()
    }

    private fun showOtherFragment(fragment: Fragment, containerId: Int) {
        val fragmentManager: FragmentManager = supportFragmentManager
        val transaction = fragmentManager.beginTransaction()
        //transaction.setCustomAnimations(android.R.anim.slide_out_right, android.R.anim.slide_out_right)
        // Замінюємо фрагмент у переданому контейнері
        transaction.replace(containerId, fragment)
        transaction.commit()
    }

    fun button1Click(view: View) {
        showFragment(fragmentOne)
        fragmentOne.updateTextBG("Hello from Fragment One!")
    }

    fun button2Click(view: View) {
        showFragment(fragmentTwo)
        fragmentTwo.updateTextBG("Hello from Fragment Two!")
    }

    // Обробка натискання кнопки "Next"
    fun onNextButtonClick(view: View) {
        currentFragmentIndex = (currentFragmentIndex + 1) % fragmentList.size // Циклічний індекс
        showOtherFragment(fragmentList[currentFragmentIndex], R.id.frameLayout3) // Показ наступного фрагменту у frameLayout3
    }

    override fun onStart() {
        super.onStart()
        Log.i("MainActivityEvent", "onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.i("MainActivityEvent", "onResume")
    }

    override fun onRestart() {
        super.onRestart()
        Log.i("MainActivityEvent", "onRestart")
    }

    override fun onPause() {
        super.onPause()
        Log.i("MainActivityEvent", "onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.i("MainActivityEvent", "onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i("MainActivityEvent", "onDestroy")
    }
}
